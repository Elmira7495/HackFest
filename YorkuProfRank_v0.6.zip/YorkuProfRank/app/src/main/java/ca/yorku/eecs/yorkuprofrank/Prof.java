package ca.yorku.eecs.yorkuprofrank;

import java.util.ArrayList;

public class Prof
{
    private String lastName;
    private String sureName;
    private int n = 0;
    private ArrayList<Courses> cour;
    private ArrayList<Rate> rate;
    public Prof() {}
    public Prof(String lastName , String sureName)
    {
        this.lastName = lastName;
        this.sureName = sureName;
        cour =  new ArrayList<>();
    }

    public String getLastName()
    {
        return lastName;
    }

    public void setLastName(String lastName)
    {
        this.lastName = lastName;
    }

    public String getSureName()
    {
        return sureName;
    }

    public void setSureName(String sureName)
    {
        this.sureName = sureName;
    }


    public void addCourse(Courses x){
        cour.add(x);

    }
    public void addRate(Rate x) {
        rate.add(x);
    }




}
