package ca.yorku.eecs.yorkuprofrank;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Spinner;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.List;

public class YorkuRank extends AppCompatActivity
{
    Spinner campusDropdownMenue;
    Spinner factDropdownMenue;
    Spinner profDropdownMenue;
    Spinner courseDropdownMenue;

    @Override
    protected void onCreate(Bundle savedInstanceState){
        super.onCreate(savedInstanceState);
        setContentView(R.layout.layout);
        campusDropdownMenue = (Spinner) findViewById(R.id.Campus);
        List<String> campusList = new ArrayList<>();
        campusList.add("Select one: ");
        campusList.add("Keele Campus");
        campusList.add("Gelendon Campus");
        ArrayAdapter<String> campusAdapter = new ArrayAdapter<String>(this, android.R.layout.simple_spinner_item, campusList);
        campusAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        campusDropdownMenue.setAdapter(campusAdapter);
        campusDropdownMenue.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener()
        {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id)
            {
                String itemValue = parent.getItemAtPosition(position).toString();
                Toast.makeText(YorkuRank.this, "Selected: " + itemValue, Toast.LENGTH_LONG).show();

                if(itemValue == "Keele Campus")
                {

                    factDropdownMenue = (Spinner) findViewById(R.id.fact);
                    List<String> factList = new ArrayList<>();
                    factList.add("Select one: ");
                    factList.add("Lassonde");
                    ArrayAdapter<String> factAdapter = new ArrayAdapter<String>(YorkuRank.this, android.R.layout.simple_spinner_item, factList);
                    factAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
                    factDropdownMenue.setAdapter(factAdapter);
                    factDropdownMenue.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener()
                    {
                        @Override
                        public void onItemSelected(AdapterView<?> parent, View view, int position, long id)
                        {
                            String itemValue = parent.getItemAtPosition(position).toString();
                            Toast.makeText(YorkuRank.this, "Selected: " + itemValue, Toast.LENGTH_LONG).show();



                        }

                        @Override
                        public void onNothingSelected(AdapterView<?> parent)
                        {

                        }
                    });

                }
                else{

                    factDropdownMenue = (Spinner) findViewById(R.id.fact);
                    List<String> factList = new ArrayList<>();
                    factList.add("Select one: ");
                    factList.add("N/A");
                    ArrayAdapter<String> factAdapter = new ArrayAdapter<String>(YorkuRank.this, android.R.layout.simple_spinner_item, factList);
                    factAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
                    factDropdownMenue.setAdapter(factAdapter);
                }

            }

            @Override
            public void onNothingSelected(AdapterView<?> parent)
            {

            }
        });

    }

}
