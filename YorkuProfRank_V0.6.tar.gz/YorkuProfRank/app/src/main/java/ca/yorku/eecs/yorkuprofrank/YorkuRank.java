package ca.yorku.eecs.yorkuprofrank;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.List;

public class YorkuRank extends AppCompatActivity
{
    Spinner campusDropdownMenue;
    Spinner factDropdownMenue;
    Spinner profDropdownMenue;
    Spinner courseDropdownMenue;

    @Override
    protected void onCreate(Bundle savedInstanceState){
        super.onCreate(savedInstanceState);
        setContentView(R.layout.layout);
        campusDropdownMenue = (Spinner) findViewById(R.id.Campus);
        List<String> campusList = new ArrayList<>();
        campusList.add("Select one: ");
        campusList.add("Keele Campus");
        campusList.add("Gelendon Campus");
        ArrayAdapter<String> campusAdapter = new ArrayAdapter<String>(this, android.R.layout.simple_spinner_item, campusList);
        campusAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        campusDropdownMenue.setAdapter(campusAdapter);
        campusDropdownMenue.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener()
        {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id)
            {
                String itemValue = parent.getItemAtPosition(position).toString();
                Toast.makeText(YorkuRank.this, "Selected: " + itemValue, Toast.LENGTH_LONG).show();

                if(itemValue == "Keele Campus")
                {

                    factDropdownMenue = (Spinner) findViewById(R.id.fact);
                    List<String> factList = new ArrayList<>();
                    factList.add("Select one: ");
                    factList.add("Lassonde School of Engineering");
                    factList.add("Faculty of Education");
                    factList.add("Faculty of Environmental Studies");
                    factList.add("Faculty of Fine Arts");
                    factList.add("Glendon");
                    factList.add("Faculty of Graduate Studies");
                    factList.add("Faculty of Health");
                    factList.add("Faculty of Liberal Arts & Professional Studies");
                    factList.add("Osgoode Hall Law School");
                    factList.add("Schulich School of Business");
                    factList.add("Faculty of Science");
                    ArrayAdapter<String> factAdapter = new ArrayAdapter<String>(YorkuRank.this, android.R.layout.simple_spinner_item, factList);
                    factAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
                    factDropdownMenue.setAdapter(factAdapter);
                    factDropdownMenue.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener()
                    {
                        @Override
                        public void onItemSelected(AdapterView<?> parent, View view, int position, long id)
                        {
                            String itemValue = parent.getItemAtPosition(position).toString();
                            Toast.makeText(YorkuRank.this, "Selected: " + itemValue, Toast.LENGTH_LONG).show();

                            if(itemValue == "Lassonde School of Engineering"){
                                profDropdownMenue = (Spinner) findViewById(R.id.prof);
                                List<String> profList = new ArrayList<>();
                                profList.add("Select one: ");
                                profList.add("Baljko, Melanie");
                                profList.add("Datta, Suprakash ");
                                profList.add("Chinaei, Amir ");
                                profList.add("Edmonds, Jeffrey A");
                                profList.add("Lesperance, Yves");

                                ArrayAdapter<String> profAdapter = new ArrayAdapter<String>(YorkuRank.this, android.R.layout.simple_spinner_item, profList);
                                profAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
                                profDropdownMenue.setAdapter(profAdapter);
                                profDropdownMenue.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener()
                                {
                                    @Override
                                    public void onItemSelected(AdapterView<?> parent, View view, int position, long id)
                                    {
                                        String itemValue = parent.getItemAtPosition(position).toString();
                                        Toast.makeText(YorkuRank.this, "Selected: " + itemValue, Toast.LENGTH_LONG).show();

                                        if(itemValue == "Baljko, Melanie")
                                        {
                                            courseDropdownMenue = (Spinner) findViewById(R.id.course);
                                            List<String> courseList = new ArrayList<>();
                                            courseList.add("Select one:");
                                            courseList.add("LE/EECS 1001");
                                            courseList.add("LE/EECS 3461");
                                            courseList.add("LE/EECS 4441");
                                            courseList.add("LE/EECS 5351");
                                            ArrayAdapter<String> courseAdapter = new ArrayAdapter<String>(YorkuRank.this, android.R.layout.simple_spinner_item, courseList);
                                            courseAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
                                            courseDropdownMenue.setAdapter(courseAdapter);
                                            courseDropdownMenue.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener()
                                            {
                                                @Override
                                                public void onItemSelected(AdapterView<?> parent, View view, int position, long id)
                                                {
                                                    String itemValue = parent.getItemAtPosition(position).toString();
                                                    Toast.makeText(YorkuRank.this, "Selected: " + itemValue, Toast.LENGTH_LONG).show();

                                                    if(itemValue == "LE/EECS 1001")
                                                    {
                                                        startActivity(new Intent(getApplicationContext(), RateAct.class));
                                                        //  Prof pro1 = new Prof();
                                                        //  Courses cre1 = new Courses("LE/EECS","1001");
                                                        // pro1.setSureName("Melanie");
                                                        // pro1.setLastName("Baljko");
                                                        //pro1.addCourse(cre1);
                                                        // ((TextView) findViewById(R.id.output)).setText("Hi");


                                                    }

                                                }

                                                @Override
                                                public void onNothingSelected(AdapterView<?> parent)
                                                {

                                                }
                                            });
                                        }
                                        else if(itemValue == "Datta, Suprakash")
                                        {

                                        }
                                        else if(itemValue == "Chinaei, Amir")
                                        {

                                        }
                                        else if(itemValue == "Edmonds, Jeffrey A")
                                        {

                                        }
                                        else if(itemValue == "Lesperance, Yves")
                                        {

                                        }
                                        else{

                                        }



                                    }
                                    @Override
                                    public void onNothingSelected(AdapterView<?> parent)
                                    {

                                    }
                                });
                            }
                            else{
                                profDropdownMenue = (Spinner) findViewById(R.id.prof);
                                List<String> profList = new ArrayList<>();
                                profList.add("Select one: ");
                                profList.add("N/A");
                                ArrayAdapter<String> profAdapter = new ArrayAdapter<String>(YorkuRank.this, android.R.layout.simple_spinner_item, profList);
                                profAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
                                profDropdownMenue.setAdapter(profAdapter);

                            }



                        }

                        @Override
                        public void onNothingSelected(AdapterView<?> parent)
                        {

                        }
                    });

                }
                else{

                    factDropdownMenue = (Spinner) findViewById(R.id.fact);
                    List<String> factList = new ArrayList<>();
                    factList.add("Select one: ");
                    factList.add("N/A");
                    ArrayAdapter<String> factAdapter = new ArrayAdapter<String>(YorkuRank.this, android.R.layout.simple_spinner_item, factList);
                    factAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
                    factDropdownMenue.setAdapter(factAdapter);
                }

            }

            @Override
            public void onNothingSelected(AdapterView<?> parent)
            {

            }
        });

    }

}
